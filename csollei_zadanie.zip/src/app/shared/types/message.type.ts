export type MessageType = "METAR" | "SIGMET" | "TAF";
