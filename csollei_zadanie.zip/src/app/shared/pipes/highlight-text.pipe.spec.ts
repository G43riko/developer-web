import {HighlightTextPipe} from './highlight-text.pipe';

describe('HighlightTextPipe', () => {
    it('create an instance', () => {
        const pipe = new HighlightTextPipe();
        expect(pipe).toBeTruthy();
    });
});
